* Once you started the app for the first time, Go to APIConfig and paste the openai api key and save it.

* It will create a file called api_key that save the binary data.

* A file called gpt_response in the same directory will be created to save your chat transcript with chat-gpt.

* Use shortcut keys <RETURN> to send & <Control-C> to clear.

